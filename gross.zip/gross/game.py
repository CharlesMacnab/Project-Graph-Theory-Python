from players import players
from round import round

class game:

    def __init__(self, nameOfGame):

        self.__nameOfGame = nameOfGame


    def erreur(self):
        print("Name must be only in alpha, start again")
        exit()

    def verifyCaracters(self, word):
        if not(word.isalpha()):
            self.erreur()

    def startGame(self):

        print("------------WELCOME TO SCRABBLE GAME------------\n")

        p1 = input("Please enter player1's name : ")
        self.verifyCaracters(p1)
        p2 = input("Please enter player2's name : ")
        self.verifyCaracters(p2)

        rounds = int(input("How much round do you want to play?"))

        player1 = players(p1)
        player2 = players(p2)

        oneRound = round(rounds)
        oneRound.setnbrOfRound(rounds)

        while rounds != 0:
            self.aRound(oneRound, player1, player2)
            print(player1.getPoints())
            print(player2.getPoints())

            rounds -= 1

        if player1.getPoints() > player2.getPoints():
            print(player1.getName()+"WINS!")

        if player1.getPoints() < player2.getPoints():
            print(player2.getName()+"WINS!")

        else:
            print("This is a draw")


    def aRound(self,oneRound, player1, player2):

        list1 = oneRound.randomLetters(player1.getName())
        list2 = oneRound.randomLetters(player2.getName())

        test = oneRound.searchWord(list1)
        test2 = oneRound.searchWord(list2)

        if test == 10:
            player1.setPoints(1)
        if test2 == 10:
            player2.setPoints(1)












