import string
import random
from players import players

class round:

    def __init__(self, nbrOfRound):

        self.__nbrOfRound = nbrOfRound


    def randomLetters(self, player):

        randomLetters = list()
        fileRead = open("Letters.txt", "r")
        lines = fileRead.readlines()

        for line in lines:
            randomLetters.append(line[0])
        newList = list()

        for i in range(0, 7):
            test = random.choice(randomLetters)
            newList.append(test)


        print("The letters for "+player+" are :")
        print(newList)
        return newList



    def isAnagramFunction(self,first, second, size): #FONCTION RECUPERé DU TP1
        for loop in range(0, size):
            second = second.replace(first[0], "", 1)
            first = first[1: size]
        if len(second) != 0:
            return False
        else:
            return True


    def searchWord(self, list): #FONCTION RECUPERé ET MODIFIé DU TP1
        word = ""
        for i in list:
            word += i
        firstWord = word
        fileRead = open("Dictionary.txt", "r")
        lines = fileRead.readlines()
        compteur = 0
        for line in lines:
            secondWord = line
            firstWord = firstWord.upper()
            secondWord = secondWord.upper()
            isAnagramme = False
            if len(firstWord) == len(secondWord):
                isAnagramme = self.isAnagramFunction(firstWord, secondWord, len(firstWord))
            if isAnagramme:
                print("Well Done!! This is a word in the dictionary")
                print("1 point won !")
                print(secondWord)
                compteur+=1
                return 10
        if compteur == 0:
            print("Bad Luck... This is not a word in the dictionary")
            print("0 point won")
            return 11


    def getnbrOfRound(self):
        return self.__nbrOfRound

    def setnbrOfRound(self,nbrOfRound):
        self.__nbrOfRound = nbrOfRound

