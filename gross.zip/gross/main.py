from game import game

game = game("Partie de Charles")
game.startGame()
