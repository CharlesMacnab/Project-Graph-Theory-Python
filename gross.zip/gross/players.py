class players:

    def __init__(self, name):
        self.__name = name
        self.__points = 0

    def setName(self, name):
        self.__name = name

    def getName(self):
        return self.__name

    def setPoints(self, points):
        self.__points += points

    def getPoints(self):
        return self.__points
